# GhostNexus Python SDK

**Run Python scripts on GDPR-compliant GPU cloud — billed by the second.**

[![PyPI version](https://badge.fury.io/py/ghostnexus.svg)](https://pypi.org/project/ghostnexus/)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)

GhostNexus is a decentralized GPU compute network. Submit your Python script, our distributed GPUs run it — securely, in the EU, billed by the second.

- **RTX 4090** from $0.50/hr · **A100 80GB** from $2.20/hr · **H100** from $3.50/hr
- GDPR-compliant · EU-hosted · AI Act 2026 ready
- Docker sandbox isolation · Per-second billing · No minimum deposit

---

## Install

```bash
pip install ghostnexus
```

## Quick Start

```python
import ghostnexus

client = ghostnexus.Client(api_key="gn_live_...")

# Submit a script
job = client.run("train.py")

# Wait for result
result = job.wait()
print(result.output)
print(f"Cost: ${result.cost_credits:.4f}")
```

Get your API key at [ghostnexus.net/dashboard](https://ghostnexus.net/dashboard) — $15 free credits with code `WELCOME15`.

## Examples

### Fine-tune a model

```python
import ghostnexus

client = ghostnexus.Client()  # reads GHOSTNEXUS_API_KEY env var

job = client.run("finetune_mistral.py", task_name="Mistral-7B LoRA fine-tune")
result = job.wait(timeout=7200)  # 2h max

print(result.output)
# Duration: 1h 23m
# Cost: $0.69
```

### Inline script

```python
job = client.run(
    "import torch; print(f'CUDA: {torch.cuda.is_available()}')",
    inline=True,
    task_name="cuda-check"
)
result = job.wait(timeout=30)
print(result.output)  # CUDA: True
```

### Check balance

```python
balance = client.balance()
print(f"Available credits: ${balance:.2f}")
```

### Job history

```python
jobs = client.history(limit=10)
for job in jobs:
    print(f"{job.task_name}: {job.status} — ${job.cost_credits:.4f}")
```

## Error Handling

```python
from ghostnexus.exceptions import InsufficientCreditsError, JobFailedError

try:
    job = client.run("train.py")
    result = job.wait()
except InsufficientCreditsError:
    print("Top up at https://ghostnexus.net/dashboard")
except JobFailedError as e:
    print(f"Job failed. Logs:\n{e.logs}")
```

## Environment Variable

```bash
export GHOSTNEXUS_API_KEY="gn_live_..."
```

```python
# No need to pass api_key= explicitly
client = ghostnexus.Client()
```

## Pricing

| GPU | VRAM | Price | Best for |
|-----|------|-------|----------|
| RTX 4070 | 12 GB | $0.25/hr | Inference, small models |
| RTX 4090 | 24 GB | $0.50/hr | Fine-tuning 7B–13B |
| RTX A6000 | 48 GB | $0.70/hr | Fine-tuning 30B–70B |
| A100 80GB | 80 GB | $2.20/hr | Large-scale training |
| H100 80GB | 80 GB | $3.50/hr | LLM pre-training |

Billed **per second** — no hourly rounding, no minimum.

## Links

- [Dashboard](https://ghostnexus.net/dashboard) — manage jobs and credits
- [Pricing](https://ghostnexus.net/pricing) — full GPU catalog
- [Blog](https://ghostnexus.net/blog) — tutorials and guides
- [Contact](mailto:contact@ghostnexus.net)

## License

MIT
